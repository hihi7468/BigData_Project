# project_mini_shiny_app
약 10시간짜리 shiny 미니 프로젝트 with R 


# 데이터 출처
- drink_sales.csv
    - https://www.index.go.kr/potal/main/EachDtlPageDetail.do?idx_cd=2824
- from Kaggle
    - titanic : https://www.kaggle.com/c/titanic/
    - house_prices : https://www.kaggle.com/c/house-prices-advanced-regression-techniques/